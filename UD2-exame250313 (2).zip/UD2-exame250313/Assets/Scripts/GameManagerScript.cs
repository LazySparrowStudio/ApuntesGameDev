using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

public class GameManagerScript : MonoBehaviour
{
    public GameObject drillObject;
    public GameObject hammerObject;
    public XRSocketInteractor hammerSocket;
    public XRSocketInteractor drillSocket;

    void Start()
    {
        drillObject.transform.position = drillSocket.attachTransform.position;
        hammerObject.transform.position = hammerSocket.attachTransform.position;
    }

    // Update is called once per frame
    void Update()
    {

    }
}
