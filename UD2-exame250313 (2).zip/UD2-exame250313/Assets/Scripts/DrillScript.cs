using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

public class DrillScript : MonoBehaviour
{
    private XRGrabInteractable grabInteractable;
    public AudioSource drillSound;
    public Transform mouthDrill;  // Usamos Transform en vez de GameObject para optimizar
    private float rotationSpeed = 300f;
    private bool isDrilling = false;

    void Awake()
    {
        grabInteractable = GetComponent<XRGrabInteractable>();
        if (mouthDrill == null)
        {
            mouthDrill = transform.Find("MouthDrill");
        }
    }

    void Update()
    {
        if (isDrilling)
        {
            mouthDrill.Rotate(Vector3.back * rotationSpeed * Time.deltaTime);
        }
    }

    public void ActiveDrill()
    {
        if (!drillSound.isPlaying)
        {
            drillSound.Play();
            isDrilling = true;
        }
        
    }

    public void StopDrill()
    {
        drillSound.Stop();
        isDrilling = false;
    }
}
